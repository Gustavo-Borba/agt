1-Considere o seguinte algoritmo:

int a = 0;
int b = 0;

print("Digite o valor de a:");
scan(a);
print("Digite o valor de b:");
scan(b);

int x = b;
b = a;
a = x;

print("Novo valor de a: ", a);
print("Novo valor de b: ", b);
Conforme visto em sala, faça o teste de mesa, mostrando o estado final da memória e o que foi escrito na tela durante a execução. 
Considere que os seguintes valores foram informados no terminal: 42 e 51.

Memória:

Nome          Valor
a             42
b             51

Terminal: a == 51 e b == 42

novo valor de a:51 novo valor de b:42